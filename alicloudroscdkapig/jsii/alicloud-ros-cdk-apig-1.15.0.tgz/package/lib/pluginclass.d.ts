import * as ros from '@alicloud/ros-cdk-core';
import { RosPluginClass } from './apig.generated';
export { RosPluginClass as PluginClassProperty };
/**
 * Properties for defining a `PluginClass`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-apig-pluginclass
 */
export interface PluginClassProps {
    /**
     * Property description: The description of the plugin class.
     */
    readonly description: string | ros.IResolvable;
    /**
     * Property executePriority: The execute priority of the Plugin.
     */
    readonly executePriority: number | ros.IResolvable;
    /**
     * Property executeStage: The Execution stage.
     */
    readonly executeStage: string | ros.IResolvable;
    /**
     * Property pluginClassName: The name of the plugin class.
     */
    readonly pluginClassName: string | ros.IResolvable;
    /**
     * Property version: The version of plugin class.
     */
    readonly version: string | ros.IResolvable;
    /**
     * Property versionDescription: The description of the version .
     */
    readonly versionDescription: string | ros.IResolvable;
    /**
     * Property wasmLanguage: the language of the wasm.
     */
    readonly wasmLanguage: string | ros.IResolvable;
    /**
     * Property wasmUrl: The url of the wasm.
     */
    readonly wasmUrl: string | ros.IResolvable;
    /**
     * Property alias: The alias of the plugin class.
     */
    readonly alias?: string | ros.IResolvable;
    /**
     * Property supportedMinGatewayVersion: The supported minimum gateway version.
     */
    readonly supportedMinGatewayVersion?: string | ros.IResolvable;
}
/**
 * Represents a `PluginClass`.
 */
export interface IPluginClass extends ros.IResource {
    readonly props: PluginClassProps;
    /**
     * Attribute Alias: The alias of the plugin class.
     */
    readonly attrAlias: ros.IResolvable | string;
    /**
     * Attribute Description: The description of the plugin class.
     */
    readonly attrDescription: ros.IResolvable | string;
    /**
     * Attribute Document: The document of plugin.
     */
    readonly attrDocument: ros.IResolvable | string;
    /**
     * Attribute PluginClassName: The name of the plugin class.
     */
    readonly attrPluginClassName: ros.IResolvable | string;
    /**
     * Attribute Type: The type of the plugin class.
     */
    readonly attrType: ros.IResolvable | string;
    /**
     * Attribute WasmLanguage: Wasm language.
     */
    readonly attrWasmLanguage: ros.IResolvable | string;
}
/**
 * This class encapsulates and extends the ROS resource type `ALIYUN::APIG::PluginClass`.
 * @Note This class may have some new functions to facilitate development, so it is recommended to use this class instead of `RosPluginClass`for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-apig-pluginclass
 */
export declare class PluginClass extends ros.Resource implements IPluginClass {
    protected scope: ros.Construct;
    protected id: string;
    readonly props: PluginClassProps;
    protected enableResourcePropertyConstraint: boolean;
    /**
     * Attribute Alias: The alias of the plugin class.
     */
    readonly attrAlias: ros.IResolvable | string;
    /**
     * Attribute Description: The description of the plugin class.
     */
    readonly attrDescription: ros.IResolvable | string;
    /**
     * Attribute Document: The document of plugin.
     */
    readonly attrDocument: ros.IResolvable | string;
    /**
     * Attribute PluginClassName: The name of the plugin class.
     */
    readonly attrPluginClassName: ros.IResolvable | string;
    /**
     * Attribute Type: The type of the plugin class.
     */
    readonly attrType: ros.IResolvable | string;
    /**
     * Attribute WasmLanguage: Wasm language.
     */
    readonly attrWasmLanguage: ros.IResolvable | string;
    /**
     * Param scope - scope in which this resource is defined
     * Param id    - scoped id of the resource
     * Param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: PluginClassProps, enableResourcePropertyConstraint?: boolean);
}
