import * as ros from '@alicloud/ros-cdk-core';
import { RosGroups } from './apigateway.generated';
export { RosGroups as GroupsProperty };
/**
 * Properties for defining a `Groups`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/datasource-apigateway-groups
 */
export interface GroupsProps {
    /**
     * Property groupId: API group ID.
     */
    readonly groupId?: string | ros.IResolvable;
    /**
     * Property groupName: Specified keyword of the API group name.
     */
    readonly groupName?: string | ros.IResolvable;
    /**
     * Property instanceId: API Gateway Instance ID.
     */
    readonly instanceId?: string | ros.IResolvable;
    /**
     * Property refreshOptions: The refresh strategy for the datasource resource when the stack is updated. Valid values:
     * - Never: Never refresh the datasource resource when the stack is updated.
     * - Always: Always refresh the datasource resource when the stack is updated.
     * Default is Never.
     */
    readonly refreshOptions?: string | ros.IResolvable;
    /**
     * Property sort: Sort.
     */
    readonly sort?: string | ros.IResolvable;
}
/**
 * Represents a `Groups`.
 */
export interface IGroups extends ros.IResource {
    readonly props: GroupsProps;
    /**
     * Attribute ApiGroupIds: The list of The ApiGateway group ids.
     */
    readonly attrApiGroupIds: ros.IResolvable | string;
    /**
     * Attribute ApiGroups: The information about ApiGateway groups.
     */
    readonly attrApiGroups: ros.IResolvable | string;
}
/**
 * This class encapsulates and extends the ROS resource type `DATASOURCE::ApiGateway::Groups`.
 * @Note This class may have some new functions to facilitate development, so it is recommended to use this class instead of `RosGroups`for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/datasource-apigateway-groups
 */
export declare class Groups extends ros.Resource implements IGroups {
    protected scope: ros.Construct;
    protected id: string;
    readonly props: GroupsProps;
    protected enableResourcePropertyConstraint: boolean;
    /**
     * Attribute ApiGroupIds: The list of The ApiGateway group ids.
     */
    readonly attrApiGroupIds: ros.IResolvable | string;
    /**
     * Attribute ApiGroups: The information about ApiGateway groups.
     */
    readonly attrApiGroups: ros.IResolvable | string;
    /**
     * Param scope - scope in which this resource is defined
     * Param id    - scoped id of the resource
     * Param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props?: GroupsProps, enableResourcePropertyConstraint?: boolean);
}
