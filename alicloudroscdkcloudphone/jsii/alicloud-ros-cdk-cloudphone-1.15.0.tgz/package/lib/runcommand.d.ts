import * as ros from '@alicloud/ros-cdk-core';
import { RosRunCommand } from './cloudphone.generated';
export { RosRunCommand as RunCommandProperty };
/**
 * Properties for defining a `RunCommand`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-cloudphone-runcommand
 */
export interface RunCommandProps {
    /**
     * Property command: The command that you want to run.\
     * The name can be up to 1024 bytes in length and can contain only letters, digits,
     * underscores (_), periods (.), slashes (\/), colons (:), and hyphens (-).
     */
    readonly command: string | ros.IResolvable;
    /**
     * Property instanceIds: ID of the instance executing the command.
     * Range of n: 1 ~ 10
     */
    readonly instanceIds: Array<string | ros.IResolvable> | ros.IResolvable;
    /**
     * Property runAgainOn: The stage of executing the command again.
     */
    readonly runAgainOn?: Array<string | ros.IResolvable> | ros.IResolvable;
}
/**
 * Represents a `RunCommand`.
 */
export interface IRunCommand extends ros.IResource {
    readonly props: RunCommandProps;
}
/**
 * This class encapsulates and extends the ROS resource type `ALIYUN::CloudPhone::RunCommand`.
 * @Note This class may have some new functions to facilitate development, so it is recommended to use this class instead of `RosRunCommand`for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-cloudphone-runcommand
 */
export declare class RunCommand extends ros.Resource implements IRunCommand {
    protected scope: ros.Construct;
    protected id: string;
    readonly props: RunCommandProps;
    protected enableResourcePropertyConstraint: boolean;
    /**
     * Param scope - scope in which this resource is defined
     * Param id    - scoped id of the resource
     * Param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: RunCommandProps, enableResourcePropertyConstraint?: boolean);
}
