import * as ros from '@alicloud/ros-cdk-core';
import { RosSchedule } from './fnf.generated';
export { RosSchedule as ScheduleProperty };
/**
 * Properties for defining a `Schedule`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-fnf-schedule
 */
export interface ScheduleProps {
    /**
     * Property cronExpression: Cron expression.
     */
    readonly cronExpression: string | ros.IResolvable;
    /**
     * Property flowName: Flow name.
     */
    readonly flowName: string | ros.IResolvable;
    /**
     * Property scheduleName: The name of the timed schedule. The name must meet the following requirements:
     * - It can contain letters (a-z and A-Z), digits (0-9), underscores (_), and
     * hyphens (-).
     * - It is case-sensitive.
     * - It must be 1 to 128 characters in length.
     */
    readonly scheduleName: string | ros.IResolvable;
    /**
     * Property description: Description of the schedule.
     */
    readonly description?: string | ros.IResolvable;
    /**
     * Property enable: Whether enable schedule.
     */
    readonly enable?: boolean | ros.IResolvable;
    /**
     * Property payload: The trigger message of the timed schedule. The message must be in the JSON
     * format.
     */
    readonly payload?: string | ros.IResolvable;
}
/**
 * Represents a `Schedule`.
 */
export interface ISchedule extends ros.IResource {
    readonly props: ScheduleProps;
    /**
     * Attribute FlowName: Flow name.
     */
    readonly attrFlowName: ros.IResolvable | string;
    /**
     * Attribute ScheduleId: Schedule Id
     */
    readonly attrScheduleId: ros.IResolvable | string;
    /**
     * Attribute ScheduleName: Schedule name.
     */
    readonly attrScheduleName: ros.IResolvable | string;
}
/**
 * This class encapsulates and extends the ROS resource type `ALIYUN::FNF::Schedule`.
 * @Note This class may have some new functions to facilitate development, so it is recommended to use this class instead of `RosSchedule`for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-fnf-schedule
 */
export declare class Schedule extends ros.Resource implements ISchedule {
    protected scope: ros.Construct;
    protected id: string;
    readonly props: ScheduleProps;
    protected enableResourcePropertyConstraint: boolean;
    /**
     * Attribute FlowName: Flow name.
     */
    readonly attrFlowName: ros.IResolvable | string;
    /**
     * Attribute ScheduleId: Schedule Id
     */
    readonly attrScheduleId: ros.IResolvable | string;
    /**
     * Attribute ScheduleName: Schedule name.
     */
    readonly attrScheduleName: ros.IResolvable | string;
    /**
     * Param scope - scope in which this resource is defined
     * Param id    - scoped id of the resource
     * Param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: ScheduleProps, enableResourcePropertyConstraint?: boolean);
}
