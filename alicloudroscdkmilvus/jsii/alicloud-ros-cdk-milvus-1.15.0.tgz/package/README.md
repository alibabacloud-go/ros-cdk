## Aliyun ROS MILVUS Construct Library

This module is part of the AliCloud ROS Cloud Development Kit (ROS CDK) project.

```ts
import * as MILVUS from '@alicloud/ros-cdk-milvus';
```