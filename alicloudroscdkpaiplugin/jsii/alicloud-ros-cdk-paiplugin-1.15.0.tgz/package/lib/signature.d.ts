import * as ros from '@alicloud/ros-cdk-core';
import { RosSignature } from './paiplugin.generated';
export { RosSignature as SignatureProperty };
/**
 * Properties for defining a `Signature`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-paiplugin-signature
 */
export interface SignatureProps {
    /**
     * Property name: The name of the Signature.
     */
    readonly name: string | ros.IResolvable;
    /**
     * Property description: Application instructions.
     */
    readonly description?: string | ros.IResolvable;
}
/**
 * Represents a `Signature`.
 */
export interface ISignature extends ros.IResource {
    readonly props: SignatureProps;
    /**
     * Attribute CreatedTime: The creation time of the Signature.
     */
    readonly attrCreatedTime: ros.IResolvable | string;
    /**
     * Attribute Description: Application instructions.
     */
    readonly attrDescription: ros.IResolvable | string;
    /**
     * Attribute Id: The ID of the Signature.
     */
    readonly attrId: ros.IResolvable | string;
    /**
     * Attribute Name: The name of the Signature.
     */
    readonly attrName: ros.IResolvable | string;
    /**
     * Attribute Reason: Review recommendations.
     */
    readonly attrReason: ros.IResolvable | string;
}
/**
 * This class encapsulates and extends the ROS resource type `ALIYUN::PAIPlugin::Signature`, which is used to register a signature.
 * @Note This class may have some new functions to facilitate development, so it is recommended to use this class instead of `RosSignature`for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-paiplugin-signature
 */
export declare class Signature extends ros.Resource implements ISignature {
    protected scope: ros.Construct;
    protected id: string;
    readonly props: SignatureProps;
    protected enableResourcePropertyConstraint: boolean;
    /**
     * Attribute CreatedTime: The creation time of the Signature.
     */
    readonly attrCreatedTime: ros.IResolvable | string;
    /**
     * Attribute Description: Application instructions.
     */
    readonly attrDescription: ros.IResolvable | string;
    /**
     * Attribute Id: The ID of the Signature.
     */
    readonly attrId: ros.IResolvable | string;
    /**
     * Attribute Name: The name of the Signature.
     */
    readonly attrName: ros.IResolvable | string;
    /**
     * Attribute Reason: Review recommendations.
     */
    readonly attrReason: ros.IResolvable | string;
    /**
     * Param scope - scope in which this resource is defined
     * Param id    - scoped id of the resource
     * Param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: SignatureProps, enableResourcePropertyConstraint?: boolean);
}
