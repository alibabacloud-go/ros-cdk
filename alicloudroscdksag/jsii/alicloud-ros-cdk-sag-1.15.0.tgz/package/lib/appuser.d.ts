import * as ros from '@alicloud/ros-cdk-core';
import { RosAppUser } from './sag.generated';
export { RosAppUser as AppUserProperty };
/**
 * Properties for defining a `AppUser`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-sag-appuser
 */
export interface AppUserProps {
    /**
     * Property bandwidth: The maximum bandwidth value. Unit: Kbit\/s. Valid values: 1 to 20000. Default
     * value: 2000.
     */
    readonly bandwidth: number | ros.IResolvable;
    /**
     * Property smartAgId: The ID of the SAG APP instance.
     */
    readonly smartAgId: string | ros.IResolvable;
    /**
     * Property userMail: The email address of the user. The username and password are sent to the specified
     * email address.
     */
    readonly userMail: string | ros.IResolvable;
    /**
     * Property clientIp: After this feature is enabled, you must specify the IP address of SAG APP. In this
     * case, SAG APP connects to Alibaba Cloud through the specified IP address.
     * Note The IP address must fall into the CIDR block of the private network.
     * After this feature is disabled, an IP address within the CIDR block of the private
     * network is assigned to SAG APP. Each connection to Alibaba Cloud uses a different
     * IP address.
     */
    readonly clientIp?: string | ros.IResolvable;
    /**
     * Property disable: Disable user or not.
     */
    readonly disable?: boolean | ros.IResolvable;
    /**
     * Property password: The password that is used to log on to the SAG app.
     * The password must be 8 to 32 characters in length. It can contain letters,
     * digits, underscores (_), at signs (@), and hyphens (-). It must start with a
     * letter or a digit.
     */
    readonly password?: string | ros.IResolvable;
    /**
     * Property userName: The username of the client account. The usernames of client accounts added to the
     * same SAG app instance must be unique.
     * The username must be 7 to 33 characters in length, and can contain letters,
     * digits, underscores (_), at signs (@), periods (.), and hyphens (-). It must
     * start with a letter or a digit.
     * >  For a client account, if you specify the username, you must also specify the
     * password. If you specify the password, you must specify the username.
     */
    readonly userName?: string | ros.IResolvable;
}
/**
 * Represents a `AppUser`.
 */
export interface IAppUser extends ros.IResource {
    readonly props: AppUserProps;
    /**
     * Attribute SmartAGId: The ID of the SAG APP instance.
     */
    readonly attrSmartAgId: ros.IResolvable | string;
    /**
     * Attribute UserName: The name of the user.
     */
    readonly attrUserName: ros.IResolvable | string;
}
/**
 * This class encapsulates and extends the ROS resource type `ALIYUN::SAG::AppUser`.
 * @Note This class may have some new functions to facilitate development, so it is recommended to use this class instead of `RosAppUser`for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-sag-appuser
 */
export declare class AppUser extends ros.Resource implements IAppUser {
    protected scope: ros.Construct;
    protected id: string;
    readonly props: AppUserProps;
    protected enableResourcePropertyConstraint: boolean;
    /**
     * Attribute SmartAGId: The ID of the SAG APP instance.
     */
    readonly attrSmartAgId: ros.IResolvable | string;
    /**
     * Attribute UserName: The name of the user.
     */
    readonly attrUserName: ros.IResolvable | string;
    /**
     * Param scope - scope in which this resource is defined
     * Param id    - scoped id of the resource
     * Param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: AppUserProps, enableResourcePropertyConstraint?: boolean);
}
