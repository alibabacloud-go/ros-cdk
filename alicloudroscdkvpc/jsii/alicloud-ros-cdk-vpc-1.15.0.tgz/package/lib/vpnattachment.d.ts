import * as ros from '@alicloud/ros-cdk-core';
import { RosVpnAttachment } from './vpc.generated';
export { RosVpnAttachment as VpnAttachmentProperty };
/**
 * Properties for defining a `VpnAttachment`.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-vpc-vpnattachment
 */
export interface VpnAttachmentProps {
    /**
     * Property localSubnet: The CIDR block on the VPC side. The CIDR block is used in Phase 2 negotiations.
     * Separate multiple CIDR blocks with commas (,). Example:
     * 192.168.1.0\/24,192.168.2.0\/24.
     * The following routing modes are supported:
     * *   If you set LocalSubnet and RemoteSubnet to 0.0.0.0\/0, the routing mode of the
     * IPsec-VPN connection is set to Destination Routing Mode.
     * *   If you set LocalSubnet and RemoteSubnet to specific CIDR blocks, the routing
     * mode of the IPsec-VPN connection is set to Protected Data Flows.
     */
    readonly localSubnet: string | ros.IResolvable;
    /**
     * Property remoteSubnet: The CIDR block on the data center side. This CIDR block is used in Phase 2
     * negotiations.
     * Separate multiple CIDR blocks with commas (,). Example:
     * 192.168.3.0\/24,192.168.4.0\/24.
     * The following routing modes are supported:
     * *   If you set LocalSubnet and RemoteSubnet to 0.0.0.0\/0, the routing mode of the
     * IPsec-VPN connection is set to Destination Routing Mode.
     * *   If you set LocalSubnet and RemoteSubnet to specific CIDR blocks, the routing
     * mode of the IPsec-VPN connection is set to Protected Data Flows.
     */
    readonly remoteSubnet: string | ros.IResolvable;
    /**
     * Property autoConfigRoute: Specifies whether to automatically configure routes. Valid values:
     * true (default)
     * false
     */
    readonly autoConfigRoute?: boolean | ros.IResolvable;
    /**
     * Property bgpConfig: The Border Gateway Protocol (BGP) configuration.
     * This parameter is required when the VPN gateway has dynamic BGP enabled.
     * Before you configure BGP, we recommend that you learn about how BGP works and its limits. For more information, see VPN Gateway supports BGP dynamic routing.
     * We recommend that you use a private ASN to establish a connection with Alibaba Cloud over BGP.
     * Refer to the relevant documentation for the private ASN range.
     */
    readonly bgpConfig?: RosVpnAttachment.BgpConfigProperty | ros.IResolvable;
    /**
     * Property customerGatewayId: The ID of the user gateway.
     */
    readonly customerGatewayId?: string | ros.IResolvable;
    /**
     * Property effectImmediately: Whether to delete the currently negotiated IPsec tunnel and re-initiate the negotiation. Value:
     * True: Negotiate immediately after the configuration is complete.
     * False (default): Negotiate when traffic enters.
     */
    readonly effectImmediately?: boolean | ros.IResolvable;
    /**
     * Property enableDpd: Specifies whether to enable the dead peer detection (DPD) feature. Valid values:
     * true (default) The initiator of the IPsec-VPN connection sends DPD packets to verify the existence and availability of the peer. If no response is received from the peer within a specified period of time, the connection fails. ISAKMP SAs and IPsec SAs are deleted. The IPsec tunnel is also deleted.
     * false: disables DPD. The IPsec initiator does not send DPD packets.
     */
    readonly enableDpd?: boolean | ros.IResolvable;
    /**
     * Property enableNatTraversal: Specifies whether to enable NAT traversal. Valid values:
     * true (default) After NAT traversal is enabled, the initiator does not check the UDP ports during IKE negotiations and can automatically discover NAT gateway devices along the VPN tunnel.
     * false
     */
    readonly enableNatTraversal?: boolean | ros.IResolvable;
    /**
     * Property enableTunnelsBgp: Support configuring this parameter when creating dual-tunnel mode IPsec-VPN connections.
     * Whether to enable BGP function for the tunnel. Values: **true** or **false** (default value).
     * > Before adding BGP configuration, it is recommended that you first understand the working mechanism and usage limitations of the BGP dynamic routing function. For more information, please see Configuring BGP Dynamic Routing.
     */
    readonly enableTunnelsBgp?: boolean | ros.IResolvable;
    /**
     * Property healthCheckConfig: This parameter is supported if you create an IPsec-VPN connection in
     * single-tunnel mode.
     * The health check configurations:
     * *   HealthCheckConfig.enable: indicates whether the health check is enabled.
     * Valid values: true and false (default).
     * *   HealthCheckConfig.dip: the destination IP address configured for health
     * checks. Enter the IP address of the on-premises data center that the VPC can
     * access through the IPsec connection.
     * *   HealthCheckConfig.sip: the source IP address configured for health checks.
     * Enter the IP address of the VPC that the on-premises data center can access
     * through the IPsec connection.
     * *   HealthCheckConfig.interval: the time interval of health check retries. Unit:
     * seconds. Default value: 3.
     * *   HealthCheckConfig.retry: the maximum number of health check retries. Default
     * value: 3.
     * *   HealthCheckConfig.Policy: specifies whether to withdraw published routes when
     * health checks fail. Valid values:
     * *   revoke_route (default): withdraws published routes.
     * *   reserve_route: does not withdraw published routes.
     */
    readonly healthCheckConfig?: RosVpnAttachment.HealthCheckConfigProperty | ros.IResolvable;
    /**
     * Property ikeConfig: Configuration information for the first phase of negotiation.
     */
    readonly ikeConfig?: RosVpnAttachment.IkeConfigProperty | ros.IResolvable;
    /**
     * Property ipsecConfig: Configuration information for the second phase negotiation.
     */
    readonly ipsecConfig?: RosVpnAttachment.IpsecConfigProperty | ros.IResolvable;
    /**
     * Property name: The name of the IPsec-VPN connection.
     * The name must be 1 to 100 characters in length and cannot start with `http:\/\/` or
     * `https:\/\/`.
     */
    readonly name?: string | ros.IResolvable;
    /**
     * Property networkType: The network type of the IPsec connection. Value: public|private.
     */
    readonly networkType?: string | ros.IResolvable;
    /**
     * Property remoteCaCert: The peer CA certificate when a ShangMi (SM) VPN gateway is used to establish the IPsec-VPN connection.
     * This parameter is required when an SM VPN gateway is used to establish the IPsec-VPN connection.
     * You can ignore this parameter when a standard VPN gateway is used to create the IPsec-VPN connection.
     */
    readonly remoteCaCert?: string | ros.IResolvable;
    /**
     * Property resourceGroupId: The resource group ID to which the IPsec connection belongs.
     * - You can call the ListResourceGroups interface to query the resource group ID.
     * - If you do not specify a resource group ID, the IPsec connection will belong to the default resource group after creation.
     */
    readonly resourceGroupId?: string | ros.IResolvable;
    /**
     * Property tunnelBandwidth: Used to indicate the bandwidth specification of a single VPN tunnel, values:
     * Standard (default value): Standard type, default bandwidth 1Gbps
     * Large: Large type, default bandwidth 3Gbps
     */
    readonly tunnelBandwidth?: string | ros.IResolvable;
    /**
     * Property tunnelOptionsSpecification: Configuration of tunnels.
     * - When creating dual-tunnel mode IPsec-VPN connections, you can configure parameters under **TunnelOptionsSpecification** array.
     * - When creating dual-tunnel mode IPsec-VPN connections, you must add two tunnels for the IPsec-VPN connection simultaneously to ensure the IPsec-VPN connection has link redundancy capability. Only two tunnels are supported under an IPsec-VPN connection.
     */
    readonly tunnelOptionsSpecification?: Array<RosVpnAttachment.TunnelOptionsSpecificationProperty | ros.IResolvable> | ros.IResolvable;
}
/**
 * Represents a `VpnAttachment`.
 */
export interface IVpnAttachment extends ros.IResource {
    readonly props: VpnAttachmentProps;
    /**
     * Attribute InternetIp: The gateway IP address of the IPsec connection.
     */
    readonly attrInternetIp: ros.IResolvable | string;
    /**
     * Attribute PeerVpnAttachmentConfig: Peer vpc Attachment config.
     */
    readonly attrPeerVpnAttachmentConfig: ros.IResolvable | string;
    /**
     * Attribute VpnAttachmentId: ID of the IPsec attachment.
     */
    readonly attrVpnAttachmentId: ros.IResolvable | string;
}
/**
 * This class encapsulates and extends the ROS resource type `ALIYUN::VPC::VpnAttachment`, which is used to create an IPsec-VPN connection. After you create the IPsec-VPN connection, you can associate the IPsec-VPN connection with a transit router.
 * @Note This class may have some new functions to facilitate development, so it is recommended to use this class instead of `RosVpnAttachment`for a more convenient development experience.
 * See https://www.alibabacloud.com/help/ros/developer-reference/aliyun-vpc-vpnattachment
 */
export declare class VpnAttachment extends ros.Resource implements IVpnAttachment {
    protected scope: ros.Construct;
    protected id: string;
    readonly props: VpnAttachmentProps;
    protected enableResourcePropertyConstraint: boolean;
    /**
     * Attribute InternetIp: The gateway IP address of the IPsec connection.
     */
    readonly attrInternetIp: ros.IResolvable | string;
    /**
     * Attribute PeerVpnAttachmentConfig: Peer vpc Attachment config.
     */
    readonly attrPeerVpnAttachmentConfig: ros.IResolvable | string;
    /**
     * Attribute VpnAttachmentId: ID of the IPsec attachment.
     */
    readonly attrVpnAttachmentId: ros.IResolvable | string;
    /**
     * Param scope - scope in which this resource is defined
     * Param id    - scoped id of the resource
     * Param props - resource properties
     */
    constructor(scope: ros.Construct, id: string, props: VpnAttachmentProps, enableResourcePropertyConstraint?: boolean);
}
